import React from "react";
import LegalDocs from "../Components/LegalDocs";

function Legal() {
  return <LegalDocs />;
}

export default Legal;
